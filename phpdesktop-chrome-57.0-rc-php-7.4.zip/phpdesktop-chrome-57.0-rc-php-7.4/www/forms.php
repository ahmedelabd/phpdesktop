<style type="text/css">@import url("style.css");</style>
<a href="index.php">Go back to index</a>
| <a href="<?php echo $_SERVER["REQUEST_URI"];?>">Refresh</a>

<title>Forms</title>
<h1>Forms</h1>

<h2>Input</h2>

type=text: <input type=text><br>
type=(empty) <input><br>
type=password: <input type=password><br>
type=checkbox: <input type=checkbox><br>
type=submit: <input type=submit><br>
type=button: <input type=button value=button><br>

<h3>Textarea</h3>

<textarea cols=60 rows=6></textarea>

<h3>Select</h3>

<select>
    <option>option 1</option>
    <option>option 2</option>
</select>